update biota_properties_spell_book set spell=4678 where spell=3957;
delete from biota_properties_enchantment_registry where spell_Id=3957;
