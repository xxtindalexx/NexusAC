/* PropertyFloat.CriticalFrequency - 46941 Modified Taulandoi */

UPDATE biota_properties_float bfloat
INNER JOIN biota ON bfloat.object_Id=biota.Id
INNER JOIN ace_world.weenie_properties_float wfloat ON wfloat.object_Id=biota.weenie_Class_Id
SET bfloat.value=wfloat.value
WHERE biota.weenie_Class_Id=46941 and bfloat.`type`=147 and wfloat.`type`=147;

/* PropertyFloat.CriticalFrequency - 46942 Modified Taulandoi */

UPDATE biota_properties_float bfloat
INNER JOIN biota ON bfloat.object_Id=biota.Id
INNER JOIN ace_world.weenie_properties_float wfloat ON wfloat.object_Id=biota.weenie_Class_Id
SET bfloat.value=wfloat.value
WHERE biota.weenie_Class_Id=46942 and bfloat.`type`=147 and wfloat.`type`=147;

/* PropertyFloat.CriticalFrequency - 46943 Modified Taulandoi */

UPDATE biota_properties_float bfloat
INNER JOIN biota ON bfloat.object_Id=biota.Id
INNER JOIN ace_world.weenie_properties_float wfloat ON wfloat.object_Id=biota.weenie_Class_Id
SET bfloat.value=wfloat.value
WHERE biota.weenie_Class_Id=46943 and bfloat.`type`=147 and wfloat.`type`=147;

/* PropertyFloat.CriticalFrequency - 46944 Modified Taulandoi */

UPDATE biota_properties_float bfloat
INNER JOIN biota ON bfloat.object_Id=biota.Id
INNER JOIN ace_world.weenie_properties_float wfloat ON wfloat.object_Id=biota.weenie_Class_Id
SET bfloat.value=wfloat.value
WHERE biota.weenie_Class_Id=46944 and bfloat.`type`=147 and wfloat.`type`=147;
