INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=48956 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=48957 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49212 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49219 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49226 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49233 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49239 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49246 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49253 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49260 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49267 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49274 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49281 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49288 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49295 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49302 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49309 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49316 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49323 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49330 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49337 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49344 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49351 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49358 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49365 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49372 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49379 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49386 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49427 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49434 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49441 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49448 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49530 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49537 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49544 AND useRequiresSkillSpec.value IS NULL;

INSERT INTO biota_properties_int (object_Id, `type`, value)
SELECT biota.id, 368, 54 /* UseRequiresSkillSpec - Summoning */ FROM biota
LEFT JOIN biota_properties_int useRequiresSkillSpec ON useRequiresSkillSpec.object_Id=biota.id AND useRequiresSkillSpec.`type`=368
WHERE biota.weenie_Class_Id=49551 AND useRequiresSkillSpec.value IS NULL;
